NOVA CLEAN WEBSITE
1. Open index.html in a browser to preview.
2. Replace +910000000000 in index.html with your real WhatsApp/phone number (country code +91, no spaces).
3. Replace the placeholder text/photos as desired.
4. Upload index.html to any static website host.

The website is responsive and includes Home, Services, About, Contact, Call and WhatsApp buttons.
